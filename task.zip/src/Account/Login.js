import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import accounts from './accounts';

export default function Login() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();
        const user = accounts.find((acc) => acc.username === username && acc.password === password);

        if (user) {
            localStorage.setItem('user', JSON.stringify(user));
            navigate('/profile');
        } else {
            setError('Неверное имя или пароль');
        }
    };

    return (
        <div>
            <h2>Login</h2>
            <form onSubmit={handleSubmit}>
                <input type="text" placeholder="Username" value={username} onChange={(e) => setUsername(e.target.value)} />
                <input type="password" placeholder="Password" value={password} onChange={(e) => setPassword(e.target.value)} />
                <button type="submit">Войти</button>
                {error && <p style={{ color: 'red' }}>{error}</p>}
            </form>
        </div>
    );
}
