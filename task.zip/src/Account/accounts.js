const accounts = [
    {
        id: 0,
        username: "",
        password: "",
        email: "",
    },
    {
        id: 1,
        username: "kalzhan",
        password: "123",
        email: "",
    },
];
export default accounts;
