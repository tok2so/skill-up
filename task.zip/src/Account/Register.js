import React, { useState } from 'react';
import accounts from './accounts';  // Импортируем список аккаунтов

export default function Register() {
    // Состояние для хранения введенных данных
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [email, setEmail] = useState('');
    const [error, setError] = useState('');
    const [successMessage, setSuccessMessage] = useState('');

    // Функция для обработки отправки формы
    const handleSubmit = (e) => {
        e.preventDefault();  // Останавливаем перезагрузку страницы при отправке формы

        // Проверка на пустые поля
        if (!username || !password || !confirmPassword || !email) {
            setError('All fields are required');
            return;
        }

        // Проверка совпадения паролей
        if (password !== confirmPassword) {
            setError('Passwords do not match');
            return;
        }

        // Проверка, существует ли уже такой пользователь
        const existingUser = accounts.find((acc) => acc.username === username);
        if (existingUser) {
            setError('Username already exists');
            return;
        }

        // Добавляем нового пользователя
        const newUser = {
            id: accounts.length,  // Генерация уникального ID
            username,
            password,
            email
        };

        // Обновляем массив аккаунтов (необходимо для локального хранения или глобального состояния)
        accounts.push(newUser);  // Добавляем нового пользователя в список (не лучший способ для реального приложения)

        setSuccessMessage('Registration successful! Please log in.');
        setUsername('');
        setPassword('');
        setConfirmPassword('');
        setEmail('');
        setError('');
    };

    return (
        <div>
            <h2>Register</h2>
            <form onSubmit={handleSubmit}>
                <div>
                    <label htmlFor="username">Username</label>
                    <input
                        type="text"
                        id="username"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="password">Password</label>
                    <input
                        type="password"
                        id="password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="confirmPassword">Confirm Password</label>
                    <input
                        type="password"
                        id="confirmPassword"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        required
                    />
                </div>
                <div>
                    <label htmlFor="email">Email</label>
                    <input
                        type="email"
                        id="email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                        required
                    />
                </div>
                {error && <p style={{ color: 'red' }}>{error}</p>}
                {successMessage && <p style={{ color: 'green' }}>{successMessage}</p>}
                <button type="submit">Register</button>
            </form>
        </div>
    );
}
