export default function Settings() {
    return <h2>Настройки</h2>;
}
