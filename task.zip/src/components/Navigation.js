import React from 'react';
import { Link } from 'react-router-dom';
import { LaptopOutlined, NotificationOutlined, UserOutlined } from '@ant-design/icons';
import type {MenuProps} from "antd";

export const TopMenuItems: MenuProps['items'] = [
    { key: 'home', label: <Link to="/Home">Home</Link> },
    { key: 'courses', label: <Link to="/Courses">Courses</Link> },
    { key: 'about', label: <Link to="/AboutUs">About Us</Link> },
];


export const SideMenuItems: MenuProps['items'] = [
    {
        key: 'sub1',
        icon: <UserOutlined />,
        label: 'User Section',
        children: [
            { key: '1', label: <Link to="/Profile">Profile</Link>},
            { key: '2', label: <Link to="/Settings">Settings</Link>},
            { key: '3', label: <Link to="/Logout">Logout</Link>},
        ],
    },
    {
        key: 'sub2',
        icon: <LaptopOutlined />,
        label: 'Learning',
        children: [
            { key: '4', label: <Link to="/MyCourses">My Courses</Link> },
            { key: '5', label: <Link to="/Assignments">Assignments</Link> },
        ],
    },
    {
        key: 'notifications',
        icon: <NotificationOutlined />,
        label: <Link to="/Notification">Notification</Link>,
    },
];
